document.addEventListener("DOMContentLoaded", function () {
    var tagline = document.querySelector("p.tagline");
    tagline.innerText = "From Cloud9 IDE!";
});